//
//  CometChatSnackBoard.h
//  CometChatSnackBoard
//
//  Created by Timothy Moose on 8/9/16.
//  Copyright © 2016 SwiftKick Mobile LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CometChatSnackBoard.
FOUNDATION_EXPORT double CometChatSnackBoardVersionNumber;

//! Project version string for CometChatSnackBoard.
FOUNDATION_EXPORT const unsigned char CometChatSnackBoardVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CometChatSnackBoard/PublicHeader.h>


