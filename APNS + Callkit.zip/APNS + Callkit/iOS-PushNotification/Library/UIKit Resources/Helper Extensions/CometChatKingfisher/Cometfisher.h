

#import <Foundation/Foundation.h>

//! Project version number for CometChatKingfisher.
FOUNDATION_EXPORT double CometChatKingfisherVersionNumber;

//! Project version string for CometChatKingfisher.
FOUNDATION_EXPORT const unsigned char CometChatKingfisherVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CometChatKingfisher/PublicHeader.h>


