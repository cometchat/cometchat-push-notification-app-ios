



//  CometChatKingfisher
//  CometChatUIKit
//  Created by CometChat Inc. on 16/10/19.
//  Copyright © 2020 CometChat Inc. All rights reserved.


import Foundation

class Box<T> {
    var value: T
    
    init(_ value: T) {
        self.value = value
    }
}
