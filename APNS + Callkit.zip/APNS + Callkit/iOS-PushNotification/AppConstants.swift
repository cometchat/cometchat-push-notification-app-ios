    //
//  Authentication.swift
//  iOS-PushNotification
//
//  Created by Admin1 on 29/03/19.
//  Copyright © 2019 Admin1. All rights reserved.
//

import Foundation

class Constants {
    
    static var appID =  ""
    static var apiKey = ""
    static var region = ""
    static var toGroupUID = ""  // Enter the GUID Of the group for which you want to send push notification.
    
}

